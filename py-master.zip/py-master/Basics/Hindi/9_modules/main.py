# import sys
# sys.path.append("C:\\Code\\modules")

from utility import area

print(area.area_circle(3))
print(area.area_square(3))