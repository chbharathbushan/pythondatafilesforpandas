import math

def area_circle(radius):
    return math.pi*(radius**2)

def area_square(length):
    return length**2

