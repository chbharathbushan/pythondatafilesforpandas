## Exercise: Python User Input

1. Write a program that can find area of a triangle. It should take base and height as
an input from user and using that it should print an area of a triangle
2. Write a program that takes file name with extension as an input and
prints just the file name without extension (you can assume that file extensions
are always 3 character long)

[Solution](https://github.com/codebasics/py/blob/master/Basics/Hindi/4_user_input/Exercise/4_user_input_exercise.py)