# while loop
n=0

while n<=10:
    print(n)
    n=n+1
